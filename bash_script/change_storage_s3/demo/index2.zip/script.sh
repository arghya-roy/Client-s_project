#!/bin/bash
echo "arghya" > file.txt